﻿# RiderDrop: COD Cash Reconciliation

A Python and SQL Server pipeline for a fictional Karachi courier company. It loads three messy exports, cleans parcel and scan records, reconciles cash-on-delivery (COD) remittances, and produces five SQL answers for Finance.

## Requirements

- Python 3 with `pandas` and `pyodbc` (see `requirements.txt`).
- Microsoft SQL Server and a login with permission to create the project database, schemas and tables.
- Microsoft ODBC Driver 18 for SQL Server, or another installed version configured in `.env`.
- SQL Server Management Studio (SSMS) to execute `setup.sql` manually.

## Setup

Run these commands in PowerShell from the project folder. Skip virtual environment creation if one already exists.

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If `.env` does not exist, create it:

```powershell
Copy-Item .env.example .env
```

Configure your server and database in `.env`. Example for a local server using Windows authentication:

```dotenv
SQL_SERVER=localhost
SQL_DATABASE=riderdrop_class
SQL_DRIVER=ODBC Driver 18 for SQL Server
```

For a named instance, use `SQL_SERVER=localhost\SQLEXPRESS`. Leave `SQL_USER` and `SQL_PASSWORD` unset for Windows authentication; set them in `.env` if SQL authentication is required. Environment variables override values in `.env`.

The Windows-authentication connection string built by `config.py` has this form:

```text
DRIVER={ODBC Driver 18 for SQL Server};SERVER=localhost;DATABASE=riderdrop_class;Trusted_Connection=yes;TrustServerCertificate=yes;
```

Keep passwords in `.env`; submit `.env.example` as the configuration template.

Open [setup.sql](setup.sql) in SSMS, connect to the same server and press **F5**. It creates `riderdrop_class` and the `raw`, `clean`, and `dq` schemas if they do not exist. If you choose a different database in `.env`, update the database references in `setup.sql` too. Use a personal database name on a shared class server.

## Run the pipeline

Generate the input files once, check the connection, then run all stages:

```powershell
python make_data.py
python 00_test_connection.py
python run_all.py
```

The implementation uses separate stage scripts, coordinated by `run_all.py`, in place of a single `pipeline.py` file.

| Script | Purpose |
|---|---|
| `01_profile_the_data.py` | Inspect missing values, formats and duplicates |
| `02_load_raw.py` | Load all three CSVs as text and compare file/table counts |
| `03_clean_tables.py` | Parse types, normalize values, deduplicate and record rejected scans |
| `04_build_parcel_final.py` | Build one row per parcel with final status, COD due and on-time flag |
| `05_answer_the_questions.py` | Execute `queries/q1.sql` through `q5.sql` and export CSV answers |
| `06_quality_checks.py` | Write 11 check results into `dq.results`; exit with failure if any check fails |

To regenerate answers and rerun checks after editing SQL queries:

```powershell
python run_all.py --from 5
```

Run `python run_all.py --from 3` to rebuild cleaning and subsequent stages. Pipeline tables and CSV outputs are replaced on rerun; input CSVs are never edited by the cleaning scripts. `dq.results` stores the latest check run rather than an append-only history.

## Cleaning decisions

- Read input CSVs with `dtype=str` and `keep_default_na=False`; store original columns as `NVARCHAR(200)` with source filename, load time and row hash for tracking.
- Parse dates explicitly as `%Y-%m-%d`, `%d/%m/%Y` or `%d-%b-%Y` to avoid ambiguous day/month interpretation.
- Trim zone names and apply title case; trim and uppercase parcel and remittance rider IDs.
- Keep the latest `updated_at` per parcel using SQL `ROW_NUMBER()`; record superseded rows in `clean.merge_log`.
- Trim and lowercase scan statuses; parse scan timestamps as `DATETIME2`.
- Store scans for unknown parcels in `clean.rejected_scans` with a reason.
- Remove repeated scans of the same parcel/status within 120 seconds of the preceding scan using SQL `LAG()`.
- Strip currency prefixes, commas and spaces from the supplied money strings and store remittances as `DECIMAL(10,2)`.
- Use the latest retained scan as final status; retain parcels without scans using a left join and the status `no_scan`.
- Set `cod_due` to `cod_amount` only for final status `delivered`; otherwise set it to zero.
- Mark a delivered parcel on time when its delivered date is on or before its promised date; calculate Q2's rate among delivered parcels only.
- Aggregate payments per parcel before joining for Q3, preserving negative shortfalls; attribute the net shortfall to the parcel's assigned rider.
- In Q5, count delivered parcels with positive COD due and no remittance row, rather than parcels whose payments sum to zero.
- Enforce primary keys on `clean.parcels` and `clean.parcel_final`.

Parsing and string normalization currently use pandas; deduplication, final-status logic and analytical answers use T-SQL. The case-study brief prefers T-SQL for transformations that can be expressed in SQL, so this implementation's parsing approach differs from that preference.

## Tables and outputs

| Object | Contents |
|---|---|
| `raw.parcels`, `raw.scans`, `raw.remittances` | Original exports with tracking columns |
| `clean.parcels_all`, `clean.scans_all` | Typed records before deduplication/rejection |
| `clean.parcels` | One typed record per parcel |
| `clean.merge_log` | Superseded parcel records and reason |
| `clean.scans`, `clean.rejected_scans` | Accepted scans and rejected unknown-parcel scans |
| `clean.remittances` | Typed remittance records |
| `clean.parcel_final` | Final parcel status, assigned rider, dates, COD due and on-time flag |
| `dq.results` | Latest checks: `check_name`, `passed`, `detail`, `run_at` |

| Question | SQL source | CSV result |
|---|---|---|
| Parcel counts by zone and final status | [q1.sql](queries/q1.sql) | [q1.csv](results/q1.csv) |
| On-time delivery rate by zone | [q2.sql](queries/q2.sql) | [q2.csv](results/q2.csv) |
| Top five riders by net COD shortfall | [q3.sql](queries/q3.sql) | [q3.csv](results/q3.csv) |
| Payments against parcels not finally delivered | [q4.sql](queries/q4.sql) | [q4.csv](results/q4.csv) |
| Delivered COD parcels without remittance | [q5.sql](queries/q5.sql) | [q5.csv](results/q5.csv) |

## Validation and findings

The last verified run passed **11 of 11 checks**, including key uniqueness, referential integrity, expected zones/statuses and delivery dates not preceding booking dates.

The generated dataset produced:

- 1,240 raw parcel rows: 1,200 retained and 40 superseded.
- 3,870 raw scan rows: 3,495 retained, 30 rejected and 345 duplicates removed.
- 734 remittance rows retained.

The scan reconciliation check derives the duplicate count by subtraction; it is an accounting summary rather than an independent measurement of removed duplicates.

Inspect the latest check records in SQL Server:

```sql
SELECT check_name, passed, detail, run_at
FROM dq.results
ORDER BY check_name;
```

Read [findings.md](findings.md) for three findings with SQL references and Finance actions: R22's Rs 76,940 net shortfall, Rs 208,760 remitted against 36 undelivered parcels, and Rs 759,440 at risk across 100 delivered COD parcels without remittance. The last amount is gross exposure for parcels with no payment row, not the overall net shortfall.

## Submission

Include `README.md`, `setup.sql`, the Python stage scripts and helpers, `run_all.py`, `requirements.txt`, `.env.example`, `queries/`, `results/`, and `findings.md`. Include `make_data.py` so the input data can be regenerated.

`results/` is currently ignored by Git. Include the generated CSVs explicitly in a submission ZIP, or use `git add -f results/q*.csv` when submitting through Git. Exclude `.env`, `venv/`, and `__pycache__/`.
