-- No remittance ROW, rather than a payment total of zero.
SELECT COUNT(*) AS delivered_cod_without_remittance,
       COALESCE(SUM(p.cod_due), 0) AS rupees_at_risk
FROM clean.parcel_final p
WHERE p.final_status = 'delivered'
  AND p.cod_due > 0
  AND NOT EXISTS (
      SELECT 1 FROM clean.remittances r WHERE r.parcel_id = p.parcel_id
  );
