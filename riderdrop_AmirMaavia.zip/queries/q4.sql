-- Remittance records exist even though the latest status is not delivered.
SELECT p.parcel_id, p.rider_id, p.zone, p.final_status,
       COUNT(*) AS remittance_count, SUM(r.amount) AS total_remitted
FROM clean.parcel_final p
JOIN clean.remittances r ON r.parcel_id = p.parcel_id
WHERE p.final_status <> 'delivered'
GROUP BY p.parcel_id, p.rider_id, p.zone, p.final_status
ORDER BY total_remitted DESC, p.parcel_id;
