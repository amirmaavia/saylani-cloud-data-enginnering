-- Aggregate remittances BEFORE joining so multiple payments do not multiply COD.
-- Keep negative shortfalls: payments against undelivered parcels also count.
WITH remitted AS (
    SELECT parcel_id, SUM(amount) AS total_remitted
    FROM clean.remittances
    GROUP BY parcel_id
)
SELECT TOP (5) p.rider_id,
       SUM(p.cod_due) AS total_cod_due,
       SUM(COALESCE(r.total_remitted, 0)) AS total_remitted,
       SUM(p.cod_due - COALESCE(r.total_remitted, 0)) AS total_shortfall
FROM clean.parcel_final p
LEFT JOIN remitted r ON r.parcel_id = p.parcel_id
GROUP BY p.rider_id
ORDER BY total_shortfall DESC, p.rider_id;
