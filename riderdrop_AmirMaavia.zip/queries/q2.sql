-- Delivery timeliness among delivered parcels in each zone.
SELECT zone,
       COUNT(*) AS delivered_parcels,
       SUM(on_time) AS on_time_parcels,
       CAST(100.0 * SUM(on_time) / NULLIF(COUNT(*), 0)
            AS DECIMAL(6,2)) AS on_time_rate_pct
FROM clean.parcel_final
WHERE final_status = 'delivered'
GROUP BY zone
ORDER BY zone;
