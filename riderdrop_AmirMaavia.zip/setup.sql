-- Run this file in SQL Server Management Studio (SSMS).
-- Database matches this project's current SQL_DATABASE: riderdrop_class.
-- If SQL_DATABASE changes in .env, update both database names below.
-- Existing databases, schemas and tables are preserved when re-run.

USE [master];
GO

IF DB_ID(N'riderdrop_class') IS NULL
    CREATE DATABASE [riderdrop_class];
GO

USE [riderdrop_class];
GO

IF SCHEMA_ID(N'raw') IS NULL
    EXEC(N'CREATE SCHEMA [raw] AUTHORIZATION [dbo];');
GO

IF SCHEMA_ID(N'clean') IS NULL
    EXEC(N'CREATE SCHEMA [clean] AUTHORIZATION [dbo];');
GO

IF SCHEMA_ID(N'dq') IS NULL
    EXEC(N'CREATE SCHEMA [dq] AUTHORIZATION [dbo];');
GO

-- Verify that all three schemas exist.
SELECT name AS schema_name
FROM sys.schemas
WHERE name IN (N'raw', N'clean', N'dq')
ORDER BY name;
